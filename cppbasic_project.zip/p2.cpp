#include <iostream>

// 아래 처럼 동작하는 Point 클래스를 작성해 주세요
// 조건 : 아래 main 코드의 주석대로 동작해야 합니다.


int main()
{
//	Point p = { 1,2 };		// 1. error 나와야 합니다.

	const Point p1{ 1,1 };	
	const Point p2{ 5,5 };

	std::cout << p2.get_x() << std::endl; // 2. 5 나와야 합니다.

	const Point p3 = p1 + p2;

	std::cout << p3 << std::endl;	// 3. 6, 6 으로 출력되어야 합니다.
}
