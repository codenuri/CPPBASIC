#include <iostream>

// 아래 main 함수가 동작할 수 있도록 Date 클래스를 완성해 보세요

class Date
{
    // 아래 main 이 문제 없이 실행되도록
    // 이 부분을 구현해 보세요
};

int main()
{
    Date today{ 2024, 9, 30 };

    std::cout << today.is_leap_year()     << std::endl; // true
    std::cout << Date::is_leap_year(2025) << std::endl; // false

    Date t1 = today.tomorrow();
    std::cout << t1 << std::endl;	// 2024-10-01 나와야 합니다.
                                    // today 가 다른 날짜라도 결과가 
									// 정확히 나와야 합니다.
}
